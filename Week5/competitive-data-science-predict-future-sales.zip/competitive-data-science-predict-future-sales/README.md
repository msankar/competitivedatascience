Hello!
    
Below you can find a outline of how to reproduce my solution for the 1C Predict Future Sales competition.

# MODEL DETAILS:

## EDA takeaways:
1. There is a strong seasonality in Sales, peaking around holiday season and on weekends.
2. Shops and items in test are all not contained in train set
3. There are outliers in training set with price above 100000 and count above 100 which will be removed.
4. Monthly mean price exhibit an upward trend.

## Feature Engineering:
* Revenue can be obtained  from item count and price for a store/date_block/item
* Generate monthly item count, mean item count, mean price and mean sales through different groupings: by month (date_block_num) only, by month-item-shop id and by month-item
* Lag features were created for the above aggregate features for previous 1,2, 3, 6, 12 months.
* KFold Mean Encoding of item count was created as discussed in Week3 lectures of the course. This feature has the second highest predictive  power.
* tf-idf feature was generated for Item Name. Had a marginal impact on predictive power.
* To capture price trends, changes in prices over the previous 3 month period was calculated using month item mean price. This feature also had very strong predictive power.

## Model:
* Choose tree-based model XGBoost. 
* Training data was data from month 0 to month 32
* Validation data was month 33
* Test data to be forecast was for month 34
* Hyper-parameter were tuned and finally settled on max_depth = 10, min_child_weight=0.5, subsample = 1, eta = 0.3, n_estimators=100, seed = 1, nthread = 5
* Validation RMSE was 0.94428
* Submitted Test forecast to Coursera grader and passed with a score of 8/10. My public and private LB scores are: 0.996306 and 0.985225
* Features with the most predictive power (top 10) include shop_id, item_count kfold mean encoding, price trends in the past 3 months, and lag features of monthy sales, item_count, and price.

#ARCHIVE CONTENTS
* input/item_categories.csv - Item categories
* input/items.csv - Items
* input/sales_train.csv - Training data of sales from Jan 2013 - Oct 2015
* input/shops.csv - Shops details
* input/test.csv - Test data of sales for the month we should predict

* output/xgb_model - XGBoost model file trained
* output/submission_xgboost_5.csv - File submitted to grader for programming assignment

* submission/PredictSales-EDA.ipynb - Notebook containing details on exploratory data analysis
* submission/PredictSales-Model.ipynb - Notebook containing details on feature engineering, training, hyper-parameter tuning and testing the model.

#HARDWARE: (The following specs were used to create the original solution)
Macbook  2.6GHz Intel core i7 6cores

#SOFTWARE:
Python 3.7.3
pandas==0.24.2
scikit-learn==0.20.3
xgboost==1.1.1
jupyterlab==0.35.4

#DATA SETUP:
* Unzip competitive-data-science-predict-future-sales.zip. The input files are in the input folder. XGboost model trained and the submission files are in output folder. Submission folder has the notebooks one for EDA and another for Feature Engineering and Training and Prediction

#MODEL BUILD:
Option 1: 
Read xgb_model file that is placed in the output folder. And this can be used to predict items_count_month for test data.

Option 2:
Run through PredictSales-Model.ipynb notebook in Submission folder. This will do all the feature engineering and train xgboost model and finally forecast sales for 1C 
